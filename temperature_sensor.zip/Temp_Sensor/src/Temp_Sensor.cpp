//Note: Need to modify the code if a different sensor is used


#include <iostream>
#include <lm35.h>
using namespace std;

// Instantiate a temperature sensor on analog pin A1
	upm::LM35 *Celcius = new upm::LM35(1,5);

int main() {

	float T;

	while(1){


	 T	= Celcius-> getTemperature();
	 sleep(1);

	 printf ("\nTemperature is %f\n",T);
	}

  return 0;
}
