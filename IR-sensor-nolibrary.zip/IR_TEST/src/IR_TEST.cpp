#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <mraa.h>
#include <unistd.h>
#include <math.h>
#include "irsensor.h"

using namespace std;

// Instantiate a irsensor on analog pin A1
sensor::irsensor *volts = new sensor::irsensor(1);

sensor::irsensor *volts2 = new sensor::irsensor(2);

// Define global variables for voltage
double R,A,B,C,D;
double E,F,G,H,Range;
float V;

//when we calibrate the sensors, always start out more than 15 cm away
bool long_range = true;

int main(int argc, char **argv){
	while (1){

			 V	= volts->value(4.95,1);
			 V	= volts2->value(4.95,1);
			 sleep(1);

			 // Returns distance in units of cm.
			 E = 0.0082712905;
			 F = 939.57652;
			 G = -3.3978697;
			 H = 17.339222;

			 // Curve fit.
			 R = (E + F * V) / (1 + G * V + H * V * V);

			 // Returns distance in units of cm.
			 A = 112.734;
			 B = - 18.635;
			 C = 13.78;
			 D = 2.449;

			 // Curve fit.
			  Range = (A + B * V) / (1 + C * V + D * V * V);

			 printf ("\nObstacle detected and input voltage is %.2f\t",V);
			 printf ("Distance = %.2f\n",R);
	}

	return(0);

}

