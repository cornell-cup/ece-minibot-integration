/*
 * irsensor.h
 *
 *  Created on: Feb 10, 2016
 *      Author: Aparna
 */

#ifndef IRSENSOR_H_
#define IRSENSOR_H_


#pragma once

#include <iostream>
#include <string.h>
#include <mraa/aio.h>

namespace sensor {

 class irsensor{
  public:
	  //initialize analog pin
    irsensor(int pin);

      //remove analog pin
    ~irsensor();

      //Gets an average voltage value from the sensor
    float value(float aref, uint8_t samples);

  private:
    mraa_aio_context m_aio;
    // ADC resolution
    int m_aRes;
  };
}

#endif /* IRSENSOR_H_ */
